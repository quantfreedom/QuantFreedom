This directory contains the code for performing
regression testing of the library.

This will provide developpers a way to validate that
a modificaiton to the code did not break the existing
functionality.

It will be helpful in particular for validating that the
TA-LIB is performing as expected when ported to a new
platform.

Internet access is required for the test to succeed.
